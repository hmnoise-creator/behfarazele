# تصاویر موتورها — `public/img/motors/`

این تصاویر (لوگوی برندها و شماتیک موتورها) هنوز داخل مخزن نیستند. پوشهٔ `img/motors` را از سرور شرکت کپی کنید.
صفحه‌ها 46 فایل زیر را با مسیر مطلق `/img/motors/...` باز می‌کنند:

```
disk-d1000.c4660d5a.png
disk-d1000_2.bdf43c36.png
disk-d1250.815b310d.png
disk-d1600.9922fb13.png
disk-d2000.8e1c802e.png
disk-d2500.1c38379f.png
disk-d450.5d35ec6f.png
disk-d630.c41e2107.png
disk-d630_16.c41e2107.png
disk-d800.3867555f.png
disk-d800_2.1da88ce8.png
dyna-disk-d1000.40239ba9.png
dyna-disk-d1000_2.974954e8.png
dyna-disk-d1250.0b435591.png
dyna-disk-d1600.7a464cc3.png
dyna-disk-d2000.91dbc578.png
dyna-disk-d2500.5c2f5dc8.png
dyna-disk-d630.21546031.png
dyna-disk-d630_16.6f00f7f4.png
dyna-disk-d800.a2daf315.png
dyna-disk-d800_2.925a20f8.png
dyna-drum-s1000.a1526fe1.png
dyna-drum-s1250.2831a57d.png
dyna-drum-s1600.8d7cab52.png
dyna-drum-s630.73b44344.png
dyna-drum-s800.979becb8.png
gentel-s1000.47de54fb.png
gentel-s1000_16.a59b2354.png
gentel-s1250.50b7105c.png
gentel-s1600.fa41b777.png
gentel-s2000.8bab1d5c.png
gentel-s450.fac9140e.png
gentel-s630.6f1e5109.png
gentel-s630_16.c7199910.png
gentel-s800.63906b37.png
huber-h_t24_10.52fb206c.png
huber-h_t24l.1adf20aa.png
huber-h_t32_10.6c6a7d25.png
huber-h_t32_16.e678d66a.png
huber-h_t32l.440e7eef.png
huber-h_t32s.721cd7d8.png
huber-h_t32xl.aa983446.png
logo-behfaraz.606f0bc8.png
logo-dyna.710651e8.png
logo-gentelrise.86b264f8.jpg
logo-huber.34450241.png
```
